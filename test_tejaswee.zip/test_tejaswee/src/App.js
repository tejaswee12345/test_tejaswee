import './App.css';
import Student from './Student/Students';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       <Student></Student>
      </header>
    </div>
  );
}

export default App;
